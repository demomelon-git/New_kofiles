package com.example.kofiles.ui

import android.media.MediaDataSource
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSourceException
import androidx.media3.datasource.DataSpec
import com.example.kofiles.data.ByteSource
import com.example.kofiles.data.SourceProvider

private const val CHUNK = 256 * 1024

/** Читает файл по кускам из любого ByteSource (Shizuku/ADB или локальный) — так играют даже файлы из Android/data. */
@OptIn(UnstableApi::class)
class ByteSourceDataSource(private val provider: SourceProvider) : BaseDataSource(true) {
    private var source: ByteSource? = null
    private var currentUri: Uri? = null
    private var position = 0L
    private var remaining = 0L
    private var buf = ByteArray(0)
    private var bufPos = 0
    private var opened = false

    override fun open(dataSpec: DataSpec): Long {
        currentUri = dataSpec.uri
        transferInitializing(dataSpec)
        val src = provider(dataSpec.uri.path ?: "")
        source = src
        val size = src.size()
        position = dataSpec.position
        remaining = if (dataSpec.length != C.LENGTH_UNSET.toLong()) dataSpec.length else size - position
        if (remaining < 0) throw DataSourceException(PlaybackException.ERROR_CODE_IO_READ_POSITION_OUT_OF_RANGE)
        buf = ByteArray(0)
        bufPos = 0
        opened = true
        transferStarted(dataSpec)
        return remaining
    }

    override fun read(target: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        if (remaining == 0L) return C.RESULT_END_OF_INPUT
        if (bufPos >= buf.size) {
            val want = minOf(CHUNK.toLong(), remaining).toInt()
            buf = source?.read(position, want) ?: ByteArray(0)
            bufPos = 0
            if (buf.isEmpty()) return C.RESULT_END_OF_INPUT
        }
        val n = minOf(length, buf.size - bufPos)
        System.arraycopy(buf, bufPos, target, offset, n)
        bufPos += n
        position += n
        remaining -= n
        bytesTransferred(n)
        return n
    }

    override fun getUri(): Uri? = currentUri

    override fun close() {
        if (opened) {
            opened = false
            transferEnded()
        }
        try { source?.close() } catch (e: Exception) { }
        source = null
        buf = ByteArray(0)
        bufPos = 0
        currentUri = null
    }
}

/** Для MediaMetadataRetriever: обложка, название и исполнитель из тегов трека. */
class SourceMediaDataSource(private val src: ByteSource) : MediaDataSource() {
    override fun readAt(position: Long, buffer: ByteArray, offset: Int, size: Int): Int {
        val total = src.size()
        if (position >= total) return -1
        val n = minOf(size.toLong(), total - position, CHUNK.toLong()).toInt()
        val data = src.read(position, n)
        if (data.isEmpty()) return -1
        System.arraycopy(data, 0, buffer, offset, data.size)
        return data.size
    }

    override fun getSize(): Long = src.size()

    override fun close() {
        src.close()
    }
}
